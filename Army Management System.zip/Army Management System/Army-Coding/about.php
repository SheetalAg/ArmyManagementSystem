<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
<head>
<title>Army</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome.css"/>
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css"/>
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css"/>
<link rel="stylesheet" type="text/css" href="css/jquery-ui.css"/>

<link rel="stylesheet" type="text/css" href="css/style/style.css"/>
        <script src="js/jquery-3.2.1.js"></script>
        <script src="js/jquery-ui.js"></script>
        <script src="js/bootstrap.js"></script>
    <script src="js/admin/main.js"></script>    
<style type="text/css">
body{
background-image: url('Images/bg5.jpg');
}
</style>
</head>
<?php /*include "header1.php"*/ ?>
<?php include "topmenu.php" ?>
<body>

<div class="container-fluid">
<div class="row">
<div class="col-xs-12 col-sm-12">

<br><br><br><br><br><br><br><br>
<center><h3><strong style="font-style: oblique;">About Us</strong></h3></center>
<br><br>

<div id="row">
<div class="col-xs-12 col-sm-6">
<center>
<img src="Images/aboutus.jpg" class="img-responsive" height="400em"; width="550em">
</center>
</div>
<div class="col-xs-12 col-sm-6">
	
<form style="font-size:15px; font-weight: normal; font-style: oblique;">
<ul>
<li class="">The Indian Army is the land-based branch and the largest component of the Indian Armed Forces. The President of India is the Supreme Commander of the Indian Army, and it is commanded by the Chief of Army Staff (COAS), who is a four-star general.</li><br>
<li class="">Two officers have been conferred with the rank of field marshal, a five-star rank, which is a ceremonial position of great honour.</li><br>
<li class="">The Indian Army originated from the armies of the East India Company, which eventually became the British Indian Army, and the armies of the princely states, which finally became the national army after independence.</li><br>
<li class="">The units and regiments of the Indian Army have diverse histories and have participated in a number of battles and campaigns across the world, earning a large number of battle and theatre honours before and after Independence.</li>
<li class="">The primary mission of the Indian Army is to ensure national security and national unity, defending the nation from external aggression and internal threats, and maintaining peace and security within its borders.</li>
</ul>
</form>
</div>
</div>

</div>
</div> 
</div>

<?php include "footer.php"; ?>

</body>
</html>
