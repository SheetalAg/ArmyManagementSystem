<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
<head>
<title>Army</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome.css"/>
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css"/>
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css"/>
<link rel="stylesheet" type="text/css" href="css/jquery-ui.css"/>

<link rel="stylesheet" type="text/css" href="css/style/style1.css"/>
        <script src="js/jquery-3.2.1.js"></script>
        <script src="js/jquery-ui.js"></script>
        <script src="js/bootstrap.js"></script>
        <script src="js/admin/main.js"></script>    
<style type="text/css">
body{
background-image: url('Images/bg5.jpg');
}
@media (min-width: 768px){
.circle-tile {
    margin-bottom: 30px;
}
}
.circle-tile {
    margin-bottom: 15px;
    text-align: center;
}
.circle-tile-heading {
    position: relative;
    width: 80px;
    height: 80px;
    margin: 0 auto -40px;
    border: 3px solid rgba(255,255,255,0.3);
    border-radius: 100%;
    color: #fff;
    transition: all ease-in-out .3s;
}
.circle-tile-heading .fa {
    line-height: 80px;
}

.circle-tile-content {
    padding-top: 50px;
}
.circle-tile-description {
    text-transform: uppercase;
}
.text-faded {
    color: rgba(255,255,255,0.7);
}
.circle-tile-number {
    padding: 5px 0 15px;
    font-size: 26px;
    font-weight: 700;
    line-height: 1;
}
.circle-tile-footer {
    display: block;
    padding: 5px;
    color: rgba(255,255,255,0.5);
    background-color: rgba(0,0,0,0.1);
    transition: all ease-in-out .3s;
}

.circle-tile-footer:hover {
    text-decoration: none;
    color: rgba(255,255,255,0.5);
    background-color: rgba(0,0,0,0.2);
}
.time-widget {
    margin-top: 5px;
    overflow: hidden;
    text-align: center;
    font-size: 1.75em;
}
.time-widget-heading {
    text-transform: uppercase;
    font-size: .5em;
    font-weight: 400;
    color: #fff;
}
#datetime{color:#fff;}
.tile-img {
    text-shadow: 2px 2px 3px rgba(0,0,0,0.9);
}
.tile {
    margin-bottom: 15px;
    padding: 15px;
    overflow: hidden;
    color: #fff;
}
 .dark-blue {
    background-color: #34495e;
}
.green {
    background-color: #16a085;
}
.blue {
    background-color: #2980b9;
}
.orange {
    background-color: #f39c12;
}
.red {
    background-color: #e74c3c;
}
.purple {
    background-color: #8e44ad;
}
.dark-gray {
    background-color: #7f8c8d;
}
.gray {
    background-color: #95a5a6;
}
.light-gray {
    background-color: #bdc3c7;
}
.yellow {
    background-color: #f1c40f;
}

/* -- Text Color Helper Classes */

 .text-dark-blue {
    color: #34495e;
}
.text-green {
    color: #16a085;
}
.text-blue {
    color: #2980b9;
}
.text-orange {
    color: #f39c12;
}
.text-red {
    color: #e74c3c;
}
.text-purple {
    color: #8e44ad;
}
.text-faded {
    color: rgba(255,255,255,0.7);
}

</style>
<script type="text/javascript">
$(document).ready(function(){
$('#dob').datepicker({
            /*format: "dd/mm/yyyy",*/
          dateFormat: 'dd-M-yy',
        }); 
});
</script> 
</head>
<?php /*include "header.php"*/ ?>
<?php include "chiefmenu.php" ?>
<?php /*include "scroll.php"*/ ?>
<body>

<div class="container-fluid">
<div class="row">        
<div class="col-xs-12 col-sm-12">

<br><br><br><br><br><br><br><br>

<center><h1 style="font-size:35px; font-style: oblique; text-shadow: 10px 10px 10px;"><strong>Agent Chief Home Page</strong></h1></center>
<div class="row" >
    <div class="col-lxs-12 col-sm-1"></div>
                    <div class="col-lxs-12 col-sm-5">
                        <div class="circle-tile">
                            <a href="#">
                                <div class="circle-tile-heading dark-blue">
                                    <i class="fa fa-users fa-fw fa-3x"></i>
                                </div>
                            </a>
                            <div class="circle-tile-content dark-blue">
                                <div class="circle-tile-description text-faded">
                                    TEAMS
                                </div>
                                <div class="circle-tile-number text-faded">
<?php     
include"connection.php";
$sql=mysqli_query($db,"SELECT COUNT(*) FROM team WHERE teamlead='$email' ");
while ($row=mysqli_fetch_array($sql)) {
echo $row[0];
}
?>
                                    <span id="sparklineA"></span>
                                </div>
                                <a href="viewoperations.php" class="circle-tile-footer">More Info <i class="fa fa-chevron-circle-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lxs-12 col-sm-5">
                        <div class="circle-tile">
                            <a href="#">
                                <div class="circle-tile-heading orange">
                                    <i class="fa fa-users fa-fw fa-3x"></i>
                                </div>
                            </a>
                            <div class="circle-tile-content orange">
                                <div class="circle-tile-description text-faded">
                                    WEAPON
                                </div>
                                <div class="circle-tile-number text-faded">
<?php     
include"connection.php";
$sql=mysqli_query($db,"SELECT COUNT(w.weaponid) FROM team t, weaponassign w WHERE w.teamid=t.id AND t.teamlead='$email' ");
while ($row=mysqli_fetch_array($sql)) {
echo $row[0];
}
?>
                                
                                </div>
                                <a href="viewweapondetails.php" class="circle-tile-footer">More Info <i class="fa fa-chevron-circle-right"></i></a>
                            </div>
                        </div>
                    </div>
 </div>
 <div class="row">
   <div class="col-lxs-12 col-sm-1"></div>                  
                    <div class="col-lxs-12 col-sm-5">
                        <div class="circle-tile">
                            <a href="#">
                                <div class="circle-tile-heading blue">
                                    <i class="fa fa-building-o fa-fw fa-3x"></i>
                                </div>
                            </a>
                            <div class="circle-tile-content blue">
                                <div class="circle-tile-description text-faded">
                                    TEAM AGENTS
                                </div>
                                <div class="circle-tile-number text-faded">
<?php     
include"connection.php";
$sql=mysqli_query($db,"SELECT COUNT(a.agentmailid) FROM team t, teamassign a WHERE t.id=a.teamid AND t.teamlead='$email' ");
while ($row=mysqli_fetch_array($sql)) {
echo $row[0];
}
?>
                                    
                                </div>
                                <a href="viewteam.php" class="circle-tile-footer">More Info <i class="fa fa-chevron-circle-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lxs-12 col-sm-5">
                        <div class="circle-tile">
                            <a href="#">
                                <div class="circle-tile-heading green">
                                    <i class="fa fa-building fa-fw fa-3x"></i>
                                </div>
                            </a>
                            <div class="circle-tile-content green">
                                <div class="circle-tile-description text-faded">
                                    REPORTS
                                </div>
                                <div class="circle-tile-number text-faded">
<?php     
include"connection.php";
$sql=mysqli_query($db,"SELECT COUNT(p.operationid) FROM team t, operationupdates p WHERE t.id=p.teamid AND t.teamlead='$email' ");
while ($row=mysqli_fetch_array($sql)) {
echo $row[0];
}
?>
                                </div>
                                <a href="viewoperations.php" class="circle-tile-footer">More Info <i class="fa fa-chevron-circle-right"></i></a>
                            </div>
                        </div>
                    </div>

</div>


<br><br><br><br><br><br><br><br><br>

</div>
</div> 
</div>

<?php include "footer.php"; ?>

</body>
</html>
    