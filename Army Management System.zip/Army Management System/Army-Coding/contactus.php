<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
<head>
<title>Army</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome.css"/>
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css"/>
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css"/>
<link rel="stylesheet" type="text/css" href="css/jquery-ui.css"/>

<link rel="stylesheet" type="text/css" href="css/style/style.css"/>
        <script src="js/jquery-3.2.1.js"></script>
        <script src="js/jquery-ui.js"></script>
        <script src="js/bootstrap.js"></script>
        <script src="js/admin/main.js"></script>    

<style type="text/css">
body{
background-image: url('Images/bg5.jpg');
}
</style>
</head>

<?php /*include "header1.php"*/ ?>
<?php include "topmenu.php" ?>

<body>

<div class="container-fluid">
<div class="row">
<div class="col-xs-12 col-sm-12">

<br><br><br><br><br><br><br><br><br>

<div id="row" style="padding-left:2em; padding-right:2em;">

<div class="col-xs-12 col-sm-6">

<center><h3 style="font-style: oblique; "><strong>Contact Details</strong></h3></center>
<br><br><br>
<form style="font-size:15px; font-weight: normal; font-style: oblique;">
<ul>
<li class=""><strong>Name:</strong> Army Management </li><br>
<li class=""><strong>Email ID:</strong> army@email.com</li><br>
<li class=""><strong>Contact Number:</strong> 040-654654</li><br>
<li class=""><strong>Address:</strong> Delhi, India</li><br>
</ul>
</form>
</div>
<br><br>
<div class="col-xs-12 col-sm-6">

<img src="Images/contactus3.jpg" class="img-responsive" height="380em"; width="580em">

</div>

</div>

</div>
</div> 
</div>

<?php include "footer.php"; ?>

</body>
</html>