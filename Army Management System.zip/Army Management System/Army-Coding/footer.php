<div class="row" id="footer">

	<div class="col-xs-12 col-sm-12 text-center">
<br>	
<p><span style="color:#0066ff">Project &copy;</span><span style="color: #ffffff">
	                                   ARMY MANAGEMENT SYSTEM</span></p>
	</div>
						
</div>
	

<style type="text/css">
#footer{
  background-color: #1a1a1a;
  /*background-image: url('Images/g2.gif');*/
  position: fixed;
  right: 0;
  bottom: 0;
  left: 0;
}
</style>

