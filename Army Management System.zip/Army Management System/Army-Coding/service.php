<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
<head>
<title>Army</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome.css"/>
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css"/>
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css"/>
<link rel="stylesheet" type="text/css" href="css/jquery-ui.css"/>

<link rel="stylesheet" type="text/css" href="css/style/style.css"/>
        <script src="js/jquery-3.2.1.js"></script>
        <script src="js/jquery-ui.js"></script>
        <script src="js/bootstrap.js"></script>
    	<script src="js/admin/main.js"></script>    
<style type="text/css">
body{
background-image: url('Images/bg5.jpg');
}
</style>
</head>
<?php /*include "header1.php"*/ ?>
<?php include "topmenu.php" ?>
<body>

<div class="container-fluid">
<div class="row">
<div class="col-xs-12 col-sm-12">

<br><br><br><br><br><br><br>

<center><h2><strong style="font-style: oblique;">Service</strong></h2></center>
<br><br>
      
<div id="row">
<div class="col-xs-12 col-sm-12 form-group">
    <div class="col-xs-12 col-sm-1 form-group"></div>
     
<div class="col-xs-12 col-sm-3 form-group" style="background-color:white; border-color: #AFEEEE; padding: 10px;
  box-shadow: 5px 10px 8px 8px #000000;  height: auto;  "> 

<img src="Images/s1.jpeg"  width="280" height="90"/>

<br><br>
<h5><strong>WHAT IS THE ARMY !!</strong></h5>
<br>
<h5 style="font-size:15px; font-weight: normal; font-style: oblique; line-height: 1.6;">
The Army is one of the largest and most important government organizations in the India. Its function is to defend the Indian people from aggressors with a force of qualified, skilled, and dedicated Soldiers.
</h5>    
</div>

<div class="col-xs-12 col-sm-1 form-group"></div>
<div class="col-xs-12 col-sm-3 form-group" style="background-color:white; border-color: #AFEEEE; padding: 10px;
  box-shadow: 5px 10px 8px 8px #000000;  height: auto; "> 

<img src="Images/s2.jpg"  width="280" height="100"/>

<br><br>
<h5><strong> STRUCTURE AND ORGANIZATION !!</strong></h5>
<br>
<h5 style="font-size:15px; font-weight: normal; font-style: oblique; line-height: 1.6;">
The Army is a large organization, made up of many different branches and groups. Here are some important terms you should understand as you consider a future in the military. Remember, your recruiter will also be able to answer any questions you may have, and help you understand the paths you could take in the Army. 
</h5>    
</div>

<div class="col-xs-12 col-sm-1 form-group"></div>
<div class="col-xs-12 col-sm-3 form-group" style="background-color:white; border-color: #AFEEEE; padding: 10px;
  box-shadow: 5px 10px 8px 8px #000000;  height: auto; "> 

<img src="Images/s3.jpg"  width="280" height="90"/>

<br><br>
<h5><strong>SERVING IN THE ARMY !!</strong></h5>
<br>
<h5 style="font-size:15px; font-weight: normal; font-style: oblique; line-height: 1.6;">
As a Soldier, you will have the choice whether to serve on active duty, or as a member of the Army Reserve. You will also have the choice of enlisting, or if you are qualified, commissioning into service as an Officer.
</h5>    
</div>

</div>
</div>

</div>
</div> 
</div>

<?php include "footer.php"; ?>

</body>
</html>
    