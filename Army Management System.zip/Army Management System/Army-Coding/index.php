<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
<head>
<title>Army</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome.css"/>
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css"/>
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css"/>
<link rel="stylesheet" type="text/css" href="css/jquery-ui.css"/>

<link rel="stylesheet" type="text/css" href="css/style/style1.css"/>
        <script src="js/jquery-3.2.1.js"></script>
        <script src="js/jquery-ui.js"></script>
        <script src="js/bootstrap.js"></script>
        <script src="js/admin/main.js"></script>    
<style type="text/css">
body{
	background-image: url(Images/reg1.png);
}
</style>  


     
</head>

<?php /*include "header1.php"*/ ?>
<?php include "topmenu.php" ?>
<?php /*include "scroll.php";*/ ?>

<body>

<div class="container-fluid">
<div class="row">
<div class="col-xs-12 col-sm-12">
<br><br><br><br><br><br><br><br>

<div id="Howitworks">

<br><br>

<div class="row" style="margin-left:10px;">
    <div class="col-xs-12 col-sm-8 form-group">

<span style="font-size: 550%; color: #00FFFF; ">&#9312;</span>
How is recruitment made to MES ?<br>
&nbsp;
All human resource issues such as recruitment, training, posting and promotion in respect of the officers and
 the subordinate staff are dealt through different HQs under the guidelines of Engineer-in-Chief’s Branch/Army 
 HQ as stipulated in government directives.<br>

</div>


<div class="col-xs-12 col-sm-4 form-group"><center>

<br><br><br>

<img src="Images/ind.jpg"  width="300" height="150"/></center>

</div>
  </div>

<br><br>

<div class="row">

 <div class="col-xs-12 col-sm-4 form-group"><center>
    <div style="border:0.7px solid #A9A9A9; width:100%;margin-left:0%;"></div>
<br><br><br>

<img src="Images/ind1.jpg"  width="300" height="150"/></center>

</div>



<div class="col-xs-12 col-sm-8 form-group" >

<span style="font-size: 550%; color: #FF7F50; ">&#9313;</span>
What are the allegations of corruption regarding the purchase of Tatra trucks ?<br>

The allegation is about the very high cost of the Tatra trucks to the Indian army. Tatra AS is a Czech company
 who manufactured the world-class trucks. Tatra AS has undergone a change of ownership.<br>
</div>

</div>

<br><br>

<div class="row" style="margin-left:10px;">
    <div class="col-xs-12 col-sm-8 form-group" >

<span style="font-size: 550%; color: #7CFC00; ">&#9314;</span>

What is MES ?<br>

The Military Engineer Services (MES) is one of the pillars of Corps of Engineers of the Indian Army which 
provides rear line engineering support to the Armed Forces.

</div>


    <div class="col-xs-12 col-sm-4 form-group"><center>
<div style="border:0.7px solid #A9A9A9; width:100%; margin-left:0%;"></div>
<br><br><br>

<img src="Images/ind2.jpg"  width="300" height="150"/></center>
<br><br><br><br><br>
</div>
  </div>

<div class="row">

 <div class="col-xs-12 col-sm-4 form-group"><center>
    <div style="border:0.7px solid #A9A9A9; width:100%;margin-left:0%;"></div>
<br><br><br>

<img src="Images/service2.jpg"  width="300" height="150"/></center>

</div>

<div class="col-xs-12 col-sm-8 form-group">

<span style="font-size: 550%; color: #FF7F50; ">&#9315;</span>
What is the difference between encryption and hashing ?<br>

Point 1: Encryption is reversible whereas hashing is irreversible. Hashing can be cracked using rainbow tables and collision attacks but is not reversible.
<br>
Point 2: Encryption ensures confidentiality whereas hashing ensures Integrity.
</div>

</div> 
</div>




</div>
</div>
</div>
<br><br><br><br><br><br>
<?php include "footer.php"; ?>

</body>
</html>
    




